#include <avr/io.h>
#include <avr/interrupt.h>
#include "LCD_4.h"
#include "printf.h"
#include <util/delay.h>

// ADC konstanten
#define ADC_CHANNEL 5
#define ADC_BITS 10
#define ADC_MAX ((1 << ADC_BITS) - 1)
#define REF_VOLTAGE_MV 2560

// Messbereiche
#define RANGE_A_FACTOR 0.1f	// 100	W/m^2 pro 1000 mV
#define RANGE_B_FACTOR 1.0f	// 1000	W/m^2 pro 1000 mV
#define RANGE_LED 0

// aktiver messbereich
float current_range_factor;

volatile int adc_value;

ISR(ADC_vect) {
	adc_value = ADC;
}

void io_init() {
	DDRA &= ~(1 << ADC_CHANNEL);
	DDRC |= 1 << RANGE_LED;
}

void adc_init() {
	// 2.56V Referenz
	ADMUX = 1 << REFS1 | 1 << REFS0 | ADC_CHANNEL;
	// free running interrupt-mode
	ADCSRA = 1 << ADEN | 1 << ADATE | 1 << ADIE | 1 << ADPS2 | 1 << ADPS1;
}

void adc_start() {
	ADCSRA |= 1 << ADSC;
}

void set_range_A() {
	current_range_factor = RANGE_A_FACTOR;
	PORTC &= ~(1 << RANGE_LED);
	lcd_pos(1, 7); // rechts unten
	printf("A");
}

void set_range_B() {
	current_range_factor = RANGE_B_FACTOR;
	PORTC |= 1 << RANGE_LED;
	lcd_pos(1, 7);
	printf("B");
}

int main(void) {
	io_init();
	lcd_init();
	adc_init();

	set_range_A();

	sei();
	adc_start();

	while (1) {
		// Messwert berechnen
		float voltage_mv = (float)REF_VOLTAGE_MV * adc_value / ADC_MAX;
		float result = voltage_mv * current_range_factor;

		// Werte ausgeben
		lcd_pos(0, 0);
		printf("%4dW/m2", (int)result);
		lcd_pos(1, 0);
		printf("%4dmV", (int)voltage_mv);

		// bei Bedarf Messbereich umschalten
		if(voltage_mv < 99) {
			set_range_A();
		}
		if(voltage_mv > 999) {
			set_range_B();
		}
	}
}
